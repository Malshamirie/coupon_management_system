<?php

use App\Http\Controllers\CampaignController;
use App\Http\Controllers\ContainerController;
use App\Http\Controllers\CouponController;
use App\Http\Controllers\CouponUserController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;




// Backend ====================================================
Route::group(
    [
        'prefix' => LaravelLocalization::setLocale(),
        'middleware' => [ 'localeSessionRedirect', 'localizationRedirect', 'localeViewPath', 'auth' ]
    ], function(){
    Route::resource('dashboard', DashboardController::class);
    Route::resource('setting', SettingController::class);
    // PaymentMethod ======================================================================
    Route::resource('users', UserController::class);
    Route::resource('roles', RoleController::class);
    Route::resource('containers', ContainerController::class);

    Route::post('/import-coupons', [CouponController::class, 'import'])->name('coupons.import');
    Route::get('usercodes', [CouponUserController::class, 'index'])->name('usercodes');
    Route::get('usercodes/export/excel', [CouponUserController::class, 'excel'])->name('usercodes.export.excel');




    // الصلاحيات
    Route::resource('permissions', PermissionController::class);



    Route::group(['prefix' => 'admin', 'as' => 'admin.' ], function () {
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard')->middleware('verified');
        Route::resource('containers', ContainerController::class);
        Route::resource('coupons', CouponController::class);
        Route::resource('campaigns', CampaignController::class);
        Route::get('container/{id}/coupons', [ContainerController::class, 'coupons'])->name('container.coupons');


    });


});


    Route::get('campaigns/{slug}', [CampaignController::class, 'form'])->name('campaign.form');
