@extends('backend.layouts.master')

@section('title_page')
{{trans('back.customers')}}
@endsection

@section('title')
{{trans('back.customers')}}
@endsection

@section('content')

    <div class="row">
        <div class="col-md-9 mb-1">
            @can('add_customer')
                <a class="btn btn-purple btn-sm" href="" data-toggle="modal" data-target="#add_customer">
                    <i class="mdi mdi-plus"></i>
                    {{trans('back.add_customer')}}
                </a>
                @include('backend.pages.customers.add')
            @endcan
        </div>


        @can('search_customer')
        <div class="col-md-3 mb-1">
            <form action="{{ route('customers.index') }}" method="GET" role="search">
                <div class="input-group">
                    <input type="text" class="form-control form-control-sm" name="query" value="{{old('query', request()->input('query'))}}" placeholder="search..." id="query" >
                    <button class="btn btn-purple btn-sm ml-1" type="submit" title="Search">
                        <span class="fas fa-search"></span>
                    </button>
                    <a href="{{ route('customers.index') }}" class="btn btn-success btn-sm ml-1 " type="button" title="Reload">
                        <span class="fas fa-sync-alt"></span>
                    </a>
                </div>
            </form>
        </div>
        @endcan

    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="table-responsive">
                    <table  class="table text-center  table-striped  table-bordered table-sm ">
                        <thead>
                        <tr style="background-color: rgb(232,245,252)">
                            <th>#</th>
                            <th> {{trans('back.Customer_Name')}}</th>
                            <th> {{trans('back.company_name')}}</th>
                            <th> {{trans('back.Customer_ID')}}</th>
                            <th> {{trans('back.phone')}}</th>
                            <th> {{trans('back.nationality')}}</th>
                            <th> {{trans('back.license_number')}}</th>
                            <th> {{trans('back.place_of_issue')}}</th>
                            <th> {{trans('back.date_of_issue')}}</th>
                            <th> {{trans('back.expiry_date')}}</th>
                            <th> {{trans('back.number_invoices')}}</th>
                            <th> {{trans('back.Total_amount')}}</th>
                            <th> {{trans('back.Paid')}}</th>
                            <th> {{trans('back.rest_amount')}}</th>
                            <th> {{trans('back.Created_at')}}</th>
                            <th width="150">  {{trans('back.Action')}}</th>
                        </tr>
                        </thead>

                        <tbody>
                        @foreach($customers as $key => $customer)
                            <tr>
                                <td>{{$key+ $customers->firstItem()}}</td>
                                <td>{{ $customer->name }}</td>
                                <td>{{ $customer->Company_name }}</td>
                                <td>{{ $customer->id_no }}</td>
                                <td>
                                    <a href="https://wa.me/{{ $customer->phone }}" target="_blank"> {{ $customer->phone }}</a>
                                </td>
                                <td>{{ $customer->nationality }}</td>
                                <td>{{ $customer->license_number }}</td>

                                <td>{{ $customer->place_of_issue }}</td>
                                <td>{{ $customer->date_of_issue }}</td>
                                <td>{{ $customer->expiry_date }}</td>

                                <td>{{ $customer->CarsContracts->count() }}</td>
                                <td>{{ number_format($customer->CarsContracts->sum('total_amount'), 3) }}</td>
                                <td>{{ number_format($customer->payments->sum('payment_amount'), 3) }}</td>
                                <td>{{ number_format($customer->CarsContracts->sum('total_amount') - $customer->payments->sum('payment_amount'), 3) }}</td>
                                <td>{{ $customer->created_at }}</td>
                                <td>
                                    @can('show_customer')
                                        <a class="btn btn-purple btn-xs " href="" data-toggle="modal" data-target="#customer_photos{{$customer->id}}">
                                            <i class="fas fa-images"></i>
                                        </a>
                                        @include('backend.pages.customers._customer_photos')
                                    @endcan

                                    @can('edit_customer')
                                        <a class="btn btn-success btn-xs " href="" data-toggle="modal" data-target="#edit_customer{{$customer->id}}">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        @include('backend.pages.customers.edit')
                                    @endcan

                                    @can('delete_customer')
                                        <a href="" class="btn btn-danger btn-xs " data-toggle="modal" data-target="#delete_customer{{$customer->id}}">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                        @include('backend.pages.customers.delete')
                                    @endcan
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                {!! $customers->appends(Request::all())->links() !!}
            </div>
        </div>
    </div>

@endsection

