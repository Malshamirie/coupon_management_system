<!-- Modal -->
<div class="modal fade" id="edit_customer{{$customer->id}}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">{{trans('back.Edit_Customer')}}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-left">

                <form action=" {{ route('customers.update', $customer->id) }}" method="post" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')

                    <div class="row">

                        <div class="form-group col-md-4">
                            <label for="name">{{trans('back.Customer_Name')}}</label>
                            <b class="text-danger">*</b>
                            <input type="text" class="form-control"   name="name" placeholder="{{trans('back.Customer_Name')}}" value="{{ $customer->name }}">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="Company_name">{{trans('back.company_name')}} </label>
                            <input type="text" class="form-control" name="Company_name" placeholder="{{trans('back.company_name')}}" value="{{ $customer->Company_name }}">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="id_no">{{trans('back.Customer_ID')}} </label>
                            <b class="text-danger">*</b>
                            <input type="number" class="form-control"   name="id_no" placeholder="{{trans('back.Customer_ID')}}" value="{{ $customer->id_no }}">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="phone">{{trans('back.phone')}} </label>
                            <b class="text-danger">*</b>
                            <input type="number" class="form-control"   name="phone" placeholder="{{trans('back.phone')}}" value="{{ $customer->phone }}" required>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="nationality">{{trans('back.nationality')}} </label>
                            <input type="text" class="form-control"   name="nationality" placeholder="{{trans('back.nationality')}}" value="{{ $customer->nationality }}">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="address">{{trans('back.address')}} </label>
                            <input type="text" class="form-control"   name="address" placeholder="{{trans('back.address')}}" value="{{ $customer->address }}">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="license_number">{{trans('back.license_number')}} </label>
                            <input type="text" class="form-control"   name="license_number" placeholder="{{trans('back.license_number')}}" value="{{ $customer->license_number }}">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="place_of_issue">{{trans('back.place_of_issue')}} </label>
                            <input type="text" class="form-control"   name="place_of_issue" placeholder="{{trans('back.place_of_issue')}}" value="{{ $customer->place_of_issue }}">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="date_of_issue">{{trans('back.date_of_issue')}} </label>
                            <input type="date" class="form-control"   name="date_of_issue" placeholder="{{trans('back.date_of_issue')}}" value="{{ $customer->date_of_issue }}">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="expiry_date">{{trans('back.expiry_date')}} </label>
                            <input type="date" class="form-control"   name="expiry_date" placeholder="{{trans('back.expiry_date')}}" value="{{ $customer->expiry_date }}">
                        </div>


                        <div class="form-group col-md-12">
                            <label for="notes">{{trans('back.notes')}} </label>
                            <textarea class="form-control" name="notes" rows="4"> {{ $customer->notes }}</textarea>
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">{{trans('back.Close')}}</button>
                        <button type="submit" class="btn btn-primary">{{trans('back.Save')}}</button>
                    </div>

                </form>

            </div>

        </div>
    </div>
</div>
