<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                
                &copy;<script>document.write(new Date().getFullYear())</script>
            </div>
            <div class="col-md-6">
                <div class="text-md-end footer-links d-none d-sm-block">

                </div>
            </div>
        </div>
    </div>
</footer>
