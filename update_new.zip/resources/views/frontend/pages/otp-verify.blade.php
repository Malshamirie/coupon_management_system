@extends('frontend.layouts.master')

@section('content')
<div class="container mt-5">
    <h3>تحقق من رمز التحقق (OTP)</h3>
    <form method="POST" action="{{ route('campaign.email.otp.verify.post', $campaign->slug) }}">
        @csrf
        <input type="hidden" name="email" value="{{ request('email') }}">

        <div class="mb-3">
            <label for="otp">أدخل رمز التحقق المرسل إلى بريدك الإلكتروني</label>
            <input type="text" name="otp" id="otp" class="form-control" required>
            @error('otp')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <button type="submit" class="btn btn-primary">تحقق</button>
    </form>
</div>
@endsection
