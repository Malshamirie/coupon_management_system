<!-- Start Navbar Area -->
<div class="navbar-area navbar-style-two bg-f9faff business-color bg-white">
    <div class="noke-responsive-nav">
        <div class="container">
            <div class="noke-responsive-menu">
                <a class="navbar-brand text-center m-auto">
                    <img src="{{asset(App\Models\Setting::first()->logo)}}" class=" d-block m-auto"  alt="logo" width="200">
                </a>
            </div>
        </div>
    </div>

    <div class="noke-nav">
        <div class="container-fluid">
            <nav class="navbar navbar-expand-md navbar-light">
                <a class="navbar-brand text-center m-auto">
                    <img src="{{asset(App\Models\Setting::first()->logo)}}" class=" d-block m-auto"  alt="logo" width="200">
                </a>
            </nav>
        </div>
    </div>


</div>
<!-- End Navbar Area -->
